package com.example.allexample;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class framelayout extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_framelayout);
        getWindow().setFlags(1024,1024);
    }
}