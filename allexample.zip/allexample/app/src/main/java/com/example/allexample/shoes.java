package com.example.allexample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

public class shoes extends AppCompatActivity {
    LinearLayout shoes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shoes);
        getWindow().setFlags(1024,1024);
        shoes = (LinearLayout) findViewById(R.id.shoes);
        shoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =new Intent(shoes.this,shoes2.class);
                startActivity(i);
            }
        });
    }
}