package com.example.allexample;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class shoes2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shoes2);
    }
}